<?php
return [
	// table user //
	'ADMIN_LEVEL' 		=> 1,
	'USER_LEVEL' 		=> 0,
	'STATUS_ACTIVE' 	=> 1,
	'STATUS_UNACTIVE' 	=> 0,
	'STATUS_SELL_OUT' 	=> 2,
	'HOT_PRODUCT' 		=> 1,
	'UNHOT_PRODUCT' 	=> 0,
];

?>