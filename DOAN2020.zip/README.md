- composer install
- Copy .env.example file to .env
- Open your .env file and change the database name (DB_DATABASE) to whatever you have, username (DB_USERNAME) and password (DB_PASSWORD)
- Run php artisan key:generate
- Run php artisan migrate
- Run php artisan serve 

------------ Toàn Túng Tiền --------------
