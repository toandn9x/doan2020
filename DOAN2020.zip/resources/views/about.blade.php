@extends('app')
@section('title', 'Sản phẩm khuyến mãi')
@section('content')
<div class="w3ls_w3l_banner_nav_right_grid w3ls_w3l_banner_nav_right_grid_sub">
	<div style="align-items: center;text-align: center;">
		{{ $post[0] }}
	</div>
	
</div>
@stop
@section('script')

@stop