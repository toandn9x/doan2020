<!DOCTYPE html>
<html>
<head>
 <title>New Order</title>
</head>
<body>
 
 <h1>Đơn Hàng Mới</h1>
 <p>Bạn có một đơn hàng mới từ khách hàng: <b><?php echo e($name); ?><b> - SĐT: <b><?php echo e($phone); ?></b></p>
 <p>Giao đến: <?php echo e($address); ?></p>
 <p>Đơn hàng có tổng giá là: <b style="color:red"><?php echo e($price); ?></b></p>
 <p>Click vào link sau để xem chi tiết</p>
 <p><a href="http://localhost/DOAN2020/public/admin/ql-don-hang">Xem chi tiết</a></p>
</body>
</html> <?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/email.blade.php ENDPATH**/ ?>