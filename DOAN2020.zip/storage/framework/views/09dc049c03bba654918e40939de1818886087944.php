
<?php $__env->startSection('title', 'Sản phẩm khuyến mãi'); ?>
<?php $__env->startSection('content'); ?>
<div class="w3ls_w3l_banner_nav_right_grid w3ls_w3l_banner_nav_right_grid_sub">
	<h3>Best Sale</h3>
	<hr>
	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-md-3 w3ls_w3l_banner_left" style="margin-bottom: 20px">
		<div class="hover14 column">
		<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
			<div class="agile_top_brand_left_grid_pos">
				<img src="lib/images/offer.png" alt=" " class="img-responsive" />
			</div>
			<div class="agile_top_brand_left_grid1">
				<figure>
					<div class="snipcart-item block">
						<div class="snipcart-thumb" style="height: 250px">
							<a href="<?php echo e(route('product_detail', $product->id)); ?>"><img src="images/<?php echo e($product->image); ?>" width="320px" height="150px"></a>
							<p><?php echo e($product->name); ?></p>
							<?php if(isset($product->promotional_price) && $product->promotional_price != 0): ?>
							<h4><?php echo e(number_format($product->promotional_price)); ?> đ<span><?php echo e(number_format($product->unit_price)); ?> đ</span></h4>
							<?php else: ?>
							<h4 style="text-align: center;"><?php echo e(number_format($product->unit_price)); ?> đ</h4>
							<?php endif; ?>
						</div>
						<div class="snipcart-details top_brand_home_details">
							<fieldset>
								<input type="button" value="Add to cart" class="button" id="add_product2" onclick="addCart(<?php echo e($product->id); ?>, '<?php echo e($product->image); ?>', '<?php echo e($product->unit_price); ?>', '<?php echo e($product->promotional_price ? $product->promotional_price : 0); ?>', 1)">
							</fieldset>
						</div>
					</div>
				</figure>
			</div>
		</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div style="clear: both;">
	<div style="display: flex; justify-content: center;">
		<ul class="pagination pagination-lg">
			
            <li class="page-item"><a class="page-link" href="khuyen-mai?page=1">First</a></li>
            
            <?php if($products->currentPage() > 1): ?>
                <li class="page-item"><a class="page-link" href="khuyen-mai?page=<?php echo e($products->currentPage() - 1); ?>">Previous</a></li>
            <?php endif; ?>
                <li class="page-item active"><a class="page-link" href="khuyen-mai?page=<?php echo e($products->currentPage()); ?>"><?php echo e($products->currentPage()); ?></a></li>
            <?php if($products->currentPage() < $products->lastPage()): ?>
                <li class="page-item"><a class="page-link" href="khuyen-mai?page=<?php echo e($products->currentPage() + 1); ?>"><?php echo e($products->currentPage() + 1); ?></a></li>
                <?php if($products->currentPage() < $products->lastPage() - 2): ?>
                <li class="page-item"><a class="page-link" href="khuyen-mai?page=<?php echo e($products->currentPage() + 2); ?>"><?php echo e($products->currentPage() + 2); ?></a></li>
                <?php endif; ?>
                <?php if($products->currentPage() < $products->lastPage() - 3): ?>
                <li class="page-item"><a class="page-link" href="khuyen-mai?page=<?php echo e($products->currentPage() + 3); ?>"><?php echo e($products->currentPage() + 3); ?></a></li>
                <?php endif; ?>
            <?php endif; ?>
            
            <?php if($products->currentPage() < $products->lastPage()): ?>
                <li class="page-item"><a class="page-link" href="khuyen-mai?page=<?php echo e($products->currentPage() + 1); ?>">Next</a>
            <?php endif; ?>
            <li class="page-item"><a class="page-link" href="khuyen-mai?page=<?php echo e($products->lastPage()); ?>">Last</a></li>
		</ul>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
	function addCart(product_id, product_img, product_price, product_promotion_price, qty) {
		let price = '';
		if(product_promotion_price == 'undefined' || product_promotion_price == '' || product_promotion_price == 0) {
			price = product_price;
		}
		else {
			price = product_promotion_price;
		}
		$.ajax({
	        url : '<?php echo e(route('add_cart')); ?>',
	        type : 'post',
	        data : {
	              'id'		: product_id,
	              'img' 	: product_img,
	              'price' 	: price,
	              'qty' 	: qty
	              },
	        success : function (data){
	        	let obj = JSON.parse(data);
	        	//console.log(obj);
		        if(obj.status == 1) {
		          	swal("Thêm thành công!", "Sản phẩm được thêm vào giỏ hàng", "success")
		          	.then((value) => {
					  $('#cart').val(obj.qty + ' Sản phẩm 　');
					});
		        }
	          	else swal("Lỗi!", "Có lỗi, vui lòng thử lại", "error");
	        }
	    });

	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/best_sale.blade.php ENDPATH**/ ?>