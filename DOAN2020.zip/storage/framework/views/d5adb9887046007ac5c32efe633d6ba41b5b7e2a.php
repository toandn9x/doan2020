
<?php $__env->startSection('title', 'Thêm sản phẩm'); ?>
<?php $__env->startSection('content_admin'); ?>
<style>
  th {
    width: 250px;
  }
</style>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Thêm sản phẩm</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-9">
            <div class="card card-primary">
              
              <?php if($errors->any()): ?>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="alert alert-danger"><?php echo e($error); ?></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              
              <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
              <?php endif; ?>
              
              <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
              <?php endif; ?>
              <form role="form" method="post" action="<?php echo e(route('p_add_product')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <table class="table">
                    <tr>
                      <th scope="row">Tên Sản Phẩm(<span style="color: red">*</span>)</th>
                      <td>
                        <div class="form-group">
                          <input type="text" class="form-control" id="product_name" placeholder="Enter product name" required name="product_name" minlength="6">
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">Mô tả</th>
                      <td>
                        <div class="form-group">
                          <textarea class="textarea" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid rgb(221, 221, 221); padding: 10px; display: none;" name="product_description"></textarea>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">Danh mục(<span style="color: red">*</span>)</th>
                      <td>
                        <div class="form-group">
                          <select class="form-control" id="" name="product_category" required>
                            <option value="">--Chọn danh mục--</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">Giá gốc(<span style="color: red">*</span>)</th>
                      <td>
                        <div class="form-group">
                          <input type="number" onkeydown="return event.keyCode !== 69 && event.keyCode !== 189 && event.keyCode !== 231 && event.keyCode !== 109" class="form-control" id="product_unit_price" placeholder="Enter unit price" required name="product_unit_price">
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">Giá khuyến mãi</th>
                      <td>
                        <div class="form-group">
                          <input type="number" onkeydown="return event.keyCode !== 69 && event.keyCode !== 189 && event.keyCode !== 231 && event.keyCode !== 109" class="form-control" id="product_promotion_price" placeholder="Enter promotion price" name="product_promotion_price">
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">Sản phẩm hot</th>
                      <td>
                        <div class="form-group">
                          <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" id="customSwitch1" name="is_hot" value="<?php echo e(Config::get('constants.HOT_PRODUCT')); ?>">
                            <label class="custom-control-label" for="customSwitch1">Hot</label>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">Trạng thái</th>
                      <td>
                        <div class="form-group">
                          <select class="form-control" id="" name="product_status">
                            <option value="<?php echo e(Config::get('constants.STATUS_ACTIVE')); ?>">✔ Hiển thị</option>
                            <option value="<?php echo e(Config::get('constants.STATUS_UNACTIVE')); ?>">✘ Tạm ẩn</option>
                            <option value="<?php echo e(Config::get('constants.STATUS_SELL_OUT')); ?>">〤 Hết hàng</option>
                        </select>
                      </div>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">Ảnh</th>
                      <td>
                        <div class="form-group">
                            <div class="input-group">
                              <div class="custom-file">
                                <input type="file" class="custom-file-input" id="exampleInputFile" name = "product_img">
                                <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                              </div>
                              <div class="input-group-append">
                                <span class="input-group-text" id="">Upload</span>
                              </div>
                            </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row"><button type="submit" class="btn btn-primary">Submit</button>&emsp;
                      <a href="<?php echo e(route('g_product')); ?>" class="btn btn-warning">Quay Lại</a>
                      </th>
                      <td>
                      </td>
                    </tr>
                </table>
              </form>
            </div>
          </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    </section>
  </div>
    <!-- /.content -->
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
  // check giá khuyến mãi phải nhỏ hơn giá gốc !
$('#product_promotion_price').change(function() {
    $(this).attr("max", $('#product_unit_price').val());
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/admin/product_add.blade.php ENDPATH**/ ?>