  <footer class="main-footer">
    <strong>Copyright &copy; 2019 - <?php echo date('Y') ?></strong>
    <strong>By 👍 <a href="mailto:toandn62@wru.vn">toandn62@wru.vn</a></strong>
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.5
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar --><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>