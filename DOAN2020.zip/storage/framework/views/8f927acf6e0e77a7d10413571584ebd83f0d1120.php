
<?php $__env->startSection('title', 'Sản phẩm khuyến mãi'); ?>
<?php $__env->startSection('content'); ?>
<div class="w3ls_w3l_banner_nav_right_grid w3ls_w3l_banner_nav_right_grid_sub">
	<div style="align-items: center;text-align: center;">
		<?php echo e($post[0]); ?>

	</div>
	
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/about.blade.php ENDPATH**/ ?>