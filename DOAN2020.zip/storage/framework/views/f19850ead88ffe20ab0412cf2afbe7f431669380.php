
<?php $__env->startSection('title', 'QL Email'); ?>
<?php $__env->startSection('content_admin'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>QL Email</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <a href="javascript:void(0)" class="btn btn-danger" style="" id="discount_delete">Xóa</a>
                <a href="javascript:void(0)" class="btn btn-success" style="" id="discount_email">Gửi email</a>
                <!-- SEARCH FORM -->
      			    <form class="form-inline ml-3 float-right">
      			      <div class="input-group input-group-sm">
      			        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search" id="discount_search">
      			        
      			      </div>
      			    </form>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              	<table class="table table-hover">
        				  <thead>
        				    <tr>
                      <th scope="col"></th>
        					    <th scope="col">STT</th>
        					    <th scope="col">Email</th>
        					    <th scope="col">Ngày tạo</th>
        				    </tr>
        				  </thead>
        				  <tbody id="discount_table">
        				  	<?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                          <th scope="row"><input class="form-check-input" type="checkbox" value="<?php echo e($discount->id); ?>" id="<?php echo e($discount->id); ?>"></th>
                          <th scope="row"><?php echo e($key+1); ?></th>
                          <td><?php echo e($discount->description); ?></td>
                          <td><?php echo e($discount->created_at); ?></td>
                          </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        				  </tbody>
				        </table>
            </div>
				<div class="card-footer">
        	<div class="row">
            <div class="col-md-4" id="count_discount">Show <?php echo e($discounts->count()); ?> of <?php echo e($discounts->total()); ?> result</div>
            <div class="col-md-8">  	
            	<ul class="pagination float-right">
            		
            		<li class="page-item"><a class="page-link" href="admin/ds-khuyen-mai?page=1">First</a></li>
            		
            		<?php if($discounts->currentPage() > 1): ?>
			    	        <li class="page-item"><a class="page-link" href="admin/ds-khuyen-mai?page=<?php echo e($discounts->currentPage() - 1); ?>">Previous</a></li>
			          <?php endif; ?>
			              <li class="page-item active"><a class="page-link" href="admin/ds-khuyen-mai?page=<?php echo e($discounts->currentPage()); ?>"><?php echo e($discounts->currentPage()); ?></a></li>
			          <?php if($discounts->currentPage() < $discounts->lastPage()): ?>
				            <li class="page-item"><a class="page-link" href="admin/ds-khuyen-mai?page=<?php echo e($discounts->currentPage() + 1); ?>"><?php echo e($discounts->currentPage() + 1); ?></a></li>
                    <?php if($discounts->currentPage() < $discounts->lastPage() - 2): ?>
				            <li class="page-item"><a class="page-link" href="admin/ds-khuyen-mai?page=<?php echo e($discounts->currentPage() + 2); ?>"><?php echo e($discounts->currentPage() + 2); ?></a></li>
                    <?php endif; ?>
                    <?php if($discounts->currentPage() < $discounts->lastPage() - 3): ?>
				            <li class="page-item"><a class="page-link" href="admin/ds-khuyen-mai?page=<?php echo e($discounts->currentPage() + 3); ?>"><?php echo e($discounts->currentPage() + 3); ?></a></li>
                    <?php endif; ?>
				        <?php endif; ?>
  							
  							<?php if($discounts->currentPage() < $discounts->lastPage()): ?>
  								  <li class="page-item"><a class="page-link" href="admin/ds-khuyen-mai?page=<?php echo e($discounts->currentPage() + 1); ?>">Next</a>
  							<?php endif; ?>
			          <li class="page-item"><a class="page-link" href="admin/ds-khuyen-mai?page=<?php echo e($discounts->lastPage()); ?>">Last</a></li>
			        </ul>
            </div>
      	  </div>
        </div>
              <!-- /.card-body -->
      </div>
            <!-- /.card -->
    </div>
          <!-- /.col -->
  </div>
        <!-- /.row -->
   </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
  $(document).ready(function(){
  // ajax tìm kiếm
  $('#discount_search').on('keyup',function(){
        load_ajax();
    })
    function load_ajax(){
      $.ajax({
          url : '<?php echo e(route('g_search_discount')); ?>',
          type : 'get',
          data : {

                 'key' : $('#discount_search').val(),
                },
          success : function (data){
              //console.log(data);
              $('tbody').html(data);
              $('#count_discount').html('Tìm thấy <b>' + $('#discount_table').find('tr').length + '</b> Kết quả');
          }
      });
    }
});

</script>
<script>
  // ajax xóa discount
  function ajaxDeleteDiscount(id) {
    //alert(id);
    $.confirm({
      title: 'Xác Nhận!',
      content: 'Bạn có chắc chắn muốn xóa (những) email này ?',
      type: 'red',
      typeAnimated: true,
      buttons: {
          tryAgain: {
              text: 'Ok',
              btnClass: 'btn-red',
              action: function(){
                $.ajax({
                    url : '<?php echo e(route('p_delete_discount')); ?>',
                    type : 'post',
                    data : {
                          'id': id,
                          },
                    success : function (data){
                      console.log(data);
                      if(data == "success") {
                        toastr.success('Xóa tài khoản thành công!');
                        setTimeout(function(){location.reload(); }, 1000);
                      }
                      else {
                        toastr.error('Xóa không thành công, vui lòng chọn một tài khoản!');
                      }
                    }
                });
              }
          },
          close: function () {
          }
      }
    });
  }
</script>
<script>
// xóa hàng loạt
$('#discount_delete').click(function(){
  let listId = '';
  $.each($("input[type=checkbox]:checked"), function(){
    listId += $(this).val() + ',';
  });
  listId = listId.substring(0, listId.length - 1);
  ajaxDeleteDiscount(listId);
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/admin/discount.blade.php ENDPATH**/ ?>