
<?php $__env->startSection('title', 'QL khách hàng'); ?>
<?php $__env->startSection('content_admin'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>QL Khách hàng</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <a href="<?php echo e(route('g_add_user')); ?>" class="btn btn-info">Thêm</a> | 
                <a href="<?php echo e(route('g_export_user')); ?>" class="btn btn-warning">Xuất excel</a> |
                <a href="javascript:void(0)" class="btn btn-danger" style="" id="user_delete">Xóa</a>
                <!-- SEARCH FORM -->
      			    <form class="form-inline ml-3 float-right">
      			      <div class="input-group input-group-sm">
      			        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search" id="user_search">
      			        
      			      </div>
      			      	<div class="input-group input-group-sm">
                      <select class="form-control" id="user_status">
                        <option value="">--Trạng thái--</option>
                        <option value="<?php echo e(Config::get('constants.STATUS_ACTIVE')); ?>" style="font-weight: bold!important">Đang hoạt động</option>
                        <option value="<?php echo e(Config::get('constants.STATUS_UNACTIVE')); ?>" style="font-weight: bold!important">Huỷ kích hoạt</option>
                      </select>
                    </div>
                    <div class="input-group input-group-sm">
                        <select class="form-control" id="user_level">
                          <option value="">--Quyền--</option>
                          <option value="<?php echo e(Config::get('constants.USER_LEVEL')); ?>" style="font-weight: bold!important">Người dùng</option>
                          <option value="<?php echo e(Config::get('constants.ADMIN_LEVEL')); ?>" style="font-weight: bold!important">Quản trị</option>
                        </select>
                    </div>
      			    </form>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              	<table class="table table-hover">
        				  <thead>
        				    <tr>
                      <th scope="col"></th>
        					    <th scope="col">STT</th>
        					    <th scope="col">Tên</th>
        					    <th scope="col">Email</th>
        					    <th scope="col">Trạng thái</th>
        					    <th scope="col">Quyền</th>
        					    <th scope="col">Ngày tạo</th>
        					    <th scope="col">Thao tác</th>
        				    </tr>
        				  </thead>
        				  <tbody id="user_table">
        				  	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        				        <tr>
                          <th scope="row"><input class="form-check-input" type="checkbox" value="<?php echo e($user->id); ?>" id="<?php echo e($user->id); ?>"></th>
        					      	<th scope="row"><?php echo e($key+1); ?></th>
        					      	<td><?php echo e($user->name); ?></td>
        					      	<td><?php echo e($user->email); ?></td>
        					      	<?php if($user->status == Config::get('constants.STATUS_ACTIVE')): ?>
        					      	<td>✔ Đang hoạt động</td>
        					      	<?php else: ?>
        					      	<td><span style="color:red">✘ Huỷ kích hoạt</span></td>
        					      	<?php endif; ?>
        					      	<?php if($user->level == Config::get('constants.ADMIN_LEVEL')): ?>
        					      	<td><span style="color:red">Quản trị viên</span></td>
        					      	<?php else: ?>
        					      	<td>Người dùng</td>
        					      	<?php endif; ?>
        					      	<td><?php echo e($user->created_at); ?></td>
        					      	<td>| 
        			      	      
                          	<a href="admin/ql-tai-khoan/sua/<?php echo e($user->id); ?>"><i class="fas fa-edit"></i></a> |
                          	<a href="javascript:void(0)" onclick="ajaxDeleteUser(<?php echo e($user->id); ?>)"><i class="fas fa-trash"></i></a> | 
        	                </td>
        				    	</tr>
        				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        				  </tbody>
				        </table>
            </div>
				<div class="card-footer">
        	<div class="row">
            <div class="col-md-4" id="count_user">Show <?php echo e($users->count()); ?> of <?php echo e($users->total()); ?> result</div>
            <div class="col-md-8">  	
            	<ul class="pagination float-right">
            		
            		<li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=1">First</a></li>
            		
            		<?php if($users->currentPage() > 1): ?>
			    	        <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($users->currentPage() - 1); ?>">Previous</a></li>
			          <?php endif; ?>
			              <li class="page-item active"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($users->currentPage()); ?>"><?php echo e($users->currentPage()); ?></a></li>
			          <?php if($users->currentPage() < $users->lastPage()): ?>
				            <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($users->currentPage() + 1); ?>"><?php echo e($users->currentPage() + 1); ?></a></li>
                    <?php if($users->currentPage() < $users->lastPage() - 2): ?>
				            <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($users->currentPage() + 2); ?>"><?php echo e($users->currentPage() + 2); ?></a></li>
                    <?php endif; ?>
                    <?php if($users->currentPage() < $users->lastPage() - 3): ?>
				            <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($users->currentPage() + 3); ?>"><?php echo e($users->currentPage() + 3); ?></a></li>
                    <?php endif; ?>
				        <?php endif; ?>
  							
  							<?php if($users->currentPage() < $users->lastPage()): ?>
  								  <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($users->currentPage() + 1); ?>">Next</a>
  							<?php endif; ?>
			          <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($users->lastPage()); ?>">Last</a></li>
			        </ul>
            </div>
      	  </div>
        </div>
              <!-- /.card-body -->
      </div>
            <!-- /.card -->
    </div>
          <!-- /.col -->
  </div>
        <!-- /.row -->
   </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
$(document).ready(function(){
  // ajax tìm kiếm
	$('#user_search').on('keyup',function(){
        load_ajax();
    })
    $('#user_status').on('change',function(){
        load_ajax();
    })
    $('#user_level').on('change',function(){
        load_ajax();
    })
    function load_ajax(){
      $.ajax({
          url : '<?php echo e(route('g_search_user')); ?>',
          type : 'get',
          data : {
                 'status' : $('#user_status').val(),
                 'level' : $('#user_level').val(),
                 'key' : $('#user_search').val(),
                },
          success : function (data){
              //console.log(data);
              $('tbody').html(data);
              $('#count_user').html('Tìm thấy <b>' + $('#user_table').find('tr').length + '</b> Kết quả');
          }
      });
    }
});
</script>
<script>
  // ajax xóa user
  function ajaxDeleteUser(id) {
    //alert(id);
    $.confirm({
      title: 'Xác Nhận!',
      content: 'Bạn có chắc chắn muốn xóa (những) tài khoản này ?',
      type: 'red',
      typeAnimated: true,
      buttons: {
          tryAgain: {
              text: 'Ok',
              btnClass: 'btn-red',
              action: function(){
                $.ajax({
                    url : '<?php echo e(route('p_delete_user')); ?>',
                    type : 'post',
                    data : {
                          'id': id,
                          },
                    success : function (data){
                      console.log(data);
                      if(data == "success") {
                        toastr.success('Xóa tài khoản thành công!');
                        setTimeout(function(){location.reload(); }, 1000);
                      }
                      else {
                        toastr.error('Xóa không thành công, vui lòng chọn một tài khoản!');
                      }
                    }
                });
              }
          },
          close: function () {
          }
      }
    });
  }
</script>
<script>
// xóa hàng loạt
$('#user_delete').click(function(){
  let listId = '';
  $.each($("input[type=checkbox]:checked"), function(){
    listId += $(this).val() + ',';
  });
  listId = listId.substring(0, listId.length - 1);
  ajaxDeleteUser(listId);
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/admin/customer_add.blade.php ENDPATH**/ ?>