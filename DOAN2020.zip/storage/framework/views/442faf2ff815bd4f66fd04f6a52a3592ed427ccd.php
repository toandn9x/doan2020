
<?php $__env->startSection('title', 'QL Khách hàng'); ?>
<?php $__env->startSection('content_admin'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>QL Khách hàng</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">| 
                <a href="<?php echo e(route('g_export_customer')); ?>" class="btn btn-warning">Xuất excel</a> |
                <a href="javascript:void(0)" class="btn btn-danger" style="" id="customer_delete">Xóa</a>
                <!-- SEARCH FORM -->
      			    <form class="form-inline ml-3 float-right">
      			      <div class="input-group input-group-sm">
      			        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search" id="customer_search" style="border:1px solid #000">
      			        
      			      </div>
      			    </form>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              	<table class="table table-hover">
        				  <thead>
        				    <tr>
                      <th scope="col"></th>
        					    <th scope="col">STT</th>
        					    <th scope="col">Tên</th>
        					    <th scope="col">Email</th>
        					    <th scope="col">Địa chỉ</th>
        					    <th scope="col">Số điện thoại</th>
                      <th scope="col">Ghi chú</th>
        					    <th scope="col">Ngày tạo</th>
        					    <th scope="col">Thao tác</th>
        				    </tr>
        				  </thead>
        				  <tbody id="customer_table">
        				  	<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        				        <tr>
                          <th scope="row"><input class="form-check-input" type="checkbox" value="<?php echo e($customer->id); ?>" id="<?php echo e($customer->id); ?>"></th>
        					      	<th scope="row"><?php echo e($key+1); ?></th>
        					      	<td><?php echo e($customer->name); ?></td>
        					      	<td><?php echo e($customer->email); ?></td>
        					      	<td><?php echo e($customer->address); ?></td>
                          <td><?php echo e($customer->phone); ?></td>
                          <td><?php echo e($customer->note); ?></td>
        					      	<td><?php echo e($customer->created_at); ?></td>
        					      	<td>|
                          	<a href="javascript:void(0)" onclick="ajaxDeleteCustomer(<?php echo e($customer->id); ?>)"><i class="fas fa-trash"></i></a> | 
        	                </td>
        				    	</tr>
        				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        				  </tbody>
				        </table>
            </div>
				<div class="card-footer">
        	<div class="row">
            <div class="col-md-4" id="count_customer">Show <?php echo e($customers->count()); ?> of <?php echo e($customers->total()); ?> result</div>
            <div class="col-md-8">  	
            	<ul class="pagination float-right">
            		
            		<li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=1">First</a></li>
            		
            		<?php if($customers->currentPage() > 1): ?>
			    	        <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($customers->currentPage() - 1); ?>">Previous</a></li>
			          <?php endif; ?>
			              <li class="page-item active"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($customers->currentPage()); ?>"><?php echo e($customers->currentPage()); ?></a></li>
			          <?php if($customers->currentPage() < $customers->lastPage()): ?>
				            <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($customers->currentPage() + 1); ?>"><?php echo e($customers->currentPage() + 1); ?></a></li>
                    <?php if($customers->currentPage() < $customers->lastPage() - 2): ?>
				            <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($customers->currentPage() + 2); ?>"><?php echo e($customers->currentPage() + 2); ?></a></li>
                    <?php endif; ?>
                    <?php if($customers->currentPage() < $customers->lastPage() - 3): ?>
				            <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($customers->currentPage() + 3); ?>"><?php echo e($customers->currentPage() + 3); ?></a></li>
                    <?php endif; ?>
				        <?php endif; ?>
  							
  							<?php if($customers->currentPage() < $customers->lastPage()): ?>
  								  <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($customers->currentPage() + 1); ?>">Next</a>
  							<?php endif; ?>
			          <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($customers->lastPage()); ?>">Last</a></li>
			        </ul>
            </div>
      	  </div>
        </div>
              <!-- /.card-body -->
      </div>
            <!-- /.card -->
    </div>
          <!-- /.col -->
  </div>
        <!-- /.row -->
   </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
$(document).ready(function(){
  // ajax tìm kiếm
	$('#customer_search').on('keyup',function(){
        load_ajax();
    })
    $('#customer_status').on('change',function(){
        load_ajax();
    })
    $('#customer_level').on('change',function(){
        load_ajax();
    })
    function load_ajax(){
      $.ajax({
          url : '<?php echo e(route('g_search_customer')); ?>',
          type : 'get',
          data : {
                 'key' : $('#customer_search').val(),
                },
          success : function (data){
              //console.log(data);
              $('tbody').html(data);
              $('#count_customer').html('Tìm thấy <b>' + $('#customer_table').find('tr').length + '</b> Kết quả');
          }
      });
    }
});
</script>
<script>
  // ajax xóa customer
  function ajaxDeleteCustomer(id) {
    //alert(id);
    $.confirm({
      title: 'Xác Nhận!',
      content: 'Bạn có chắc chắn muốn xóa (những) tài khoản này ?',
      type: 'red',
      typeAnimated: true,
      buttons: {
          tryAgain: {
              text: 'Ok',
              btnClass: 'btn-red',
              action: function(){
                $.ajax({
                    url : '<?php echo e(route('p_delete_customer')); ?>',
                    type : 'get',
                    data : {
                          'id': id,
                          },
                    success : function (data){
                      console.log(data);
                      if(data == "success") {
                        toastr.success('Xóa tài khoản thành công!');
                        setTimeout(function(){location.reload(); }, 1000);
                      }
                      else {
                        toastr.error('Xóa không thành công, vui lòng chọn một tài khoản!');
                      }
                    }
                });
              }
          },
          close: function () {
          }
      }
    });
  }
</script>
<script>
// xóa hàng loạt
$('#customer_delete').click(function(){
  let listId = '';
  $.each($("input[type=checkbox]:checked"), function(){
    listId += $(this).val() + ',';
  });
  listId = listId.substring(0, listId.length - 1);
  ajaxDeleteCustomer(listId);
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/admin/customer.blade.php ENDPATH**/ ?>