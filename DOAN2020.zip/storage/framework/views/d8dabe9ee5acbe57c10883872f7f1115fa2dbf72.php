
<?php $__env->startSection('title', 'Thêm tài khoản'); ?>
<?php $__env->startSection('content_admin'); ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Thêm tài khoản</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-9">
            <div class="card card-primary">
              
              <?php if($errors->any()): ?>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="alert alert-danger"><?php echo e($error); ?></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              
              <?php if(session('err')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('err')); ?>

                </div>
              <?php endif; ?>
              
              <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
              <?php endif; ?>
              <form role="form" method="post" action="<?php echo e(route('p_add_user')); ?>">
                <?php echo csrf_field(); ?>
                <table class="table">
                    <tr>
                      <th scope="row">Địa chỉ email(<span style="color: red">*</span>)</th>
                      <td>
                        <div class="form-group">
                          <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" required name="email">
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">Mật khẩu(<span style="color: red">*</span>)</th>
                      <td>
                        <div class="form-group">
                          <input type="password" class="form-control" id="pass" placeholder="Enter password" name="password" minlength="6">
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">Nhập lại mật khẩu(<span style="color: red">*</span>)</th>
                      <td>
                        <div class="form-group">
                          <input type="password" class="form-control" id="repass" placeholder="Confirm password" name="repass" minlength="6">
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">Tên đăng nhập(<span style="color: red">*</span>)</th>
                      <td>
                        <div class="form-group">
                          <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" required >
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">Loại tài khoản</th>
                      <td>
                        <div class="form-group">
                          <select class="form-control" id="" name="level">
                            <option value="<?php echo e(Config::get('constants.USER_LEVEL')); ?>">Người dùng</option>
                            <option value="<?php echo e(Config::get('constants.ADMIN_LEVEL')); ?>">Tài khoản admin</option>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row"><button type="submit" class="btn btn-primary">Submit</button>&emsp;
                      <a href="<?php echo e(route('g_user')); ?>" class="btn btn-warning">Quay Lại</a>
                      </th>
                      <td>
                      </td>
                    </tr>
                </table>
              </form>
            </div>
          </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    </section>
  </div>
    <!-- /.content -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/admin/add_user.blade.php ENDPATH**/ ?>