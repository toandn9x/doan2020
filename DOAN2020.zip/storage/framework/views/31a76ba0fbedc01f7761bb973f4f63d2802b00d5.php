
<?php $__env->startSection('title', 'QL Sản phẩm'); ?>
<?php $__env->startSection('content_admin'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>QL Sản phẩm</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <a href="<?php echo e(route('g_add_product')); ?>" class="btn btn-info">Thêm</a> | 
                <a href="<?php echo e(route('g_export_product')); ?>" class="btn btn-warning">Xuất excel</a> |
                <a href="javascript:void(0)" class="btn btn-danger" style="" id="product_delete">Xóa</a>
                <!-- SEARCH FORM -->
      			    <form class="form-inline ml-3 float-right">
      			      <div class="input-group input-group-sm">
      			        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search" id="product_search">
      			        
      			      </div>
                  <div class="input-group input-group-sm">
                      <select class="form-control" id="product_category">
                        <option value="">--Danh mục--</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" style="font-weight: bold!important"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="input-group input-group-sm">
                      <select class="form-control" id="product_status">
                        <option value="">--Trạng thái--</option>
                        <option value="<?php echo e(Config::get('constants.STATUS_ACTIVE')); ?>" style="font-weight: bold!important">Đang hiển thị</option>
                        <option value="<?php echo e(Config::get('constants.STATUS_UNACTIVE')); ?>" style="font-weight: bold!important">Đang ẩn</option>
                        <option value="<?php echo e(Config::get('constants.STATUS_SELL_OUT')); ?>" style="font-weight: bold!important">Hết hàng</option>
                      </select>
                    </div>
      			      	<div class="input-group input-group-sm">
                      <select class="form-control" id="product_hot">
                        <option value="">--Hot--</option>
                        <option value="<?php echo e(Config::get('constants.HOT_PRODUCT')); ?>" style="font-weight: bold!important">HOT</option>
                        <option value="<?php echo e(Config::get('constants.UNHOT_PRODUCT')); ?>" style="font-weight: bold!important">Không hot</option>
                      </select>
                    </div>
      			    </form>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              	<table class="table table-hover">
        				  <thead>
        				    <tr>
                      <th scope="col"></th>
        					    <th scope="col">STT</th>
        					    <th scope="col">Tên</th>
        					    <th scope="col" style="width: 100px; height: 100px">Ảnh</th>
        					    <th scope="col">Mô tả</th>
                      <th scope="col">Danh mục</th>
                      <th scope="col">Giá gốc</th>
                      <th scope="col">Giá khuyến mãi</th>
        					    <th scope="col">Trạng thái</th>
                      <th scope="col">Sản phẩm hot</th>
        					    <th scope="col">Ngày tạo</th>
        					    <th scope="col">Thao tác</th>
        				    </tr>
        				  </thead>
        				  <tbody id="product_table">
        				  	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        				        <tr>
                          <th scope="row"><input class="form-check-input" type="checkbox" value="<?php echo e($product->id); ?>" id="<?php echo e($product->id); ?>"></th>
        					      	<th scope="row"><?php echo e($key+1); ?></th>
        					      	<td><?php echo e($product->name); ?></td>
                          <td><img src="images/<?php echo e($product->image); ?>" width="200px" height="150px"></td>
                          <td><?php echo $product->description; ?></td>
                          <td><?php echo e($product->category->name); ?></td>
                          <td><?php echo e(number_format($product->unit_price)); ?></td>
                          <td><?php echo e(number_format($product->promotional_price)); ?></td>
        					      	<?php if($product->status == Config::get('constants.STATUS_ACTIVE')): ?>
        					      	<td>✔ Đang hiển thị</td>
                          <?php elseif($product->status == Config::get('constants.STATUS_SELL_OUT')): ?>
                          <td><span style="color:red">〤 Hết hàng</span></td>
        					      	<?php else: ?>
        					      	<td><span style="color:red">✘ Đang ẩn</span></td>
        					      	<?php endif; ?>
                          <?php if($product->is_hot == Config::get('constants.HOT_PRODUCT')): ?>
                          <td><span style="color:red">» HOT «</span></td>
                          <?php else: ?>
                          <td>Không hot</td>
                          <?php endif; ?>
        					      	<td><?php echo e($product->created_at); ?></td>
        					      	<td>
                          	<a href="admin/ql-san-pham/sua/<?php echo e($product->id); ?>"><i class="fas fa-edit"></i></a>&emsp;<a href="javascript:void(0)" onclick="ajaxDeleteProduct(<?php echo e($product->id); ?>)"><i class="fas fa-trash"></i></a>
        	                </td>
        				    	</tr>
        				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        				  </tbody>
				      </table>
            </div>
				<div class="card-footer">
          <div class="row">
            <div class="col-md-4" id="count_product">Show <?php echo e($products->count()); ?> of <?php echo e($products->total()); ?> result</div>
            <div class="col-md-8">    
              <ul class="pagination float-right">
                
                <li class="page-item"><a class="page-link" href="admin/ql-san-pham?page=1">First</a></li>
                
                <?php if($products->currentPage() > 1): ?>
                    <li class="page-item"><a class="page-link" href="admin/ql-san-pham?page=<?php echo e($products->currentPage() - 1); ?>">Previous</a></li>
                <?php endif; ?>
                    <li class="page-item active"><a class="page-link" href="admin/ql-danh-muc?page=<?php echo e($products->currentPage()); ?>"><?php echo e($products->currentPage()); ?></a></li>
                <?php if($products->currentPage() < $products->lastPage()): ?>
                    <li class="page-item"><a class="page-link" href="admin/ql-san-pham?page=<?php echo e($products->currentPage() + 1); ?>"><?php echo e($products->currentPage() + 1); ?></a></li>
                    <?php if($products->currentPage() < $products->lastPage() - 2): ?>
                    <li class="page-item"><a class="page-link" href="admin/ql-san-pham?page=<?php echo e($products->currentPage() + 2); ?>"><?php echo e($products->currentPage() + 2); ?></a></li>
                    <?php endif; ?>
                    <?php if($products->currentPage() < $products->lastPage() - 3): ?>
                    <li class="page-item"><a class="page-link" href="admin/ql-san-pham?page=<?php echo e($products->currentPage() + 3); ?>"><?php echo e($products->currentPage() + 3); ?></a></li>
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php if($products->currentPage() < $products->lastPage()): ?>
                    <li class="page-item"><a class="page-link" href="admin/ql-san-pham?page=<?php echo e($products->currentPage() + 1); ?>">Next</a>
                <?php endif; ?>
                <li class="page-item"><a class="page-link" href="admin/ql-san-pham?page=<?php echo e($products->lastPage()); ?>">Last</a></li>
              </ul>
            </div>
          </div>
        </div>
              <!-- /.card-body -->
      </div>
            <!-- /.card -->
    </div>
          <!-- /.col -->
  </div>
        <!-- /.row -->
   </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
$(document).ready(function(){
  // ajax tìm kiếm
	  $('#product_search').on('keyup',function(){
        load_ajax();
    })
    $('#product_category').on('change',function(){
        load_ajax();
    })
    $('#product_status').on('change',function(){
        load_ajax();
    })
    $('#product_hot').on('change',function(){
        load_ajax();
    })
    function load_ajax(){
      $.ajax({
          url : '<?php echo e(route('g_search_product')); ?>',
          type : 'get',
          data : {
                'key'           : $('#product_search').val(),
                'id_category'   : $('#product_category').val(),
                'status'        : $('#product_status').val(),
                'hot'           : $('#product_hot').val()
                },
          success : function (data){
              console.log(data);
              $('tbody').html(data);
              $('#count_product').html('Tìm thấy <b>' + $('#product_table').find('tr').length + '</b> Kết quả');
          }
      });
    }
});
</script>
<script>
  // ajax xóa user
  function ajaxDeleteProduct(id) {
    //alert(id);
    $.confirm({
      title: 'Xác Nhận!',
      content: 'Bạn có chắc chắn muốn xóa (những) sản phẩm khoản này ?',
      type: 'red',
      typeAnimated: true,
      buttons: {
          tryAgain: {
              text: 'Ok',
              btnClass: 'btn-red',
              action: function(){
                $.ajax({
                    url : '<?php echo e(route('p_delete_product')); ?>',
                    type : 'post',
                    data : {
                          'id': id,
                          },
                    success : function (data){
                      console.log(data);
                      if(data == "success") {
                        toastr.success('Xóa sản phẩm thành công!');
                        setTimeout(function(){location.reload(); }, 1000);
                      }
                      else {
                        toastr.error('Xóa không thành công, vui lòng chọn một sản phẩm!');
                      }
                    }
                });
              }
          },
          close: function () {
          }
      }
    });
  }
</script>
<script>
// xóa hàng loạt
$('#product_delete').click(function(){
  let listId = '';
  $.each($("input[type=checkbox]:checked"), function(){
    listId += $(this).val() + ',';
  });
  listId = listId.substring(0, listId.length - 1);
  ajaxDeleteProduct(listId);
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/admin/product.blade.php ENDPATH**/ ?>