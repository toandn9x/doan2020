
<?php $__env->startSection('title', 'Lịch sử đặt hàng'); ?>
<?php $__env->startSection('content'); ?>
<br><br><br><br><br>
<div class="container">
	<div class="row" style="margin-left: 160px">
		<h3>Đơn hàng của: <b><?php echo e(Auth::user()->name); ?></b></h3>
	</div>
	<div class="row" style="margin-left: 160px">
		<table class="table">
		  <thead>
		    <tr>
		      <th scope="col">STT</th>
		      <th scope="col">Mã đơn hàng</th>
		      <th scope="col">Tên Khách hàng</th>
		      <th scope="col">Địa chỉ</th>
		      <th scope="col">SĐT</th>
		      <th scope="col">Tổng tiền</th>
		      <th scope="col">Hình thức thanh toán</th>
		      <th scope="col">Hình thức vận chuyển</th>
		      <th scope="col">Trạng thái đơn hàng</th>
		      <th scope="col">Ngày đặt</th>
		      <th scope="col">Xem chi tiết</th>
		    </tr>
		  </thead>
		  <tbody>
		  	<?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <tr>
			      	<th scope="row"><?php echo e($key+1); ?></th>
			      	<td><b>#</b><?php echo e($bill->id); ?></td>
			      	<td><?php echo e(\App\Models\Customer::find($bill->id_customer)->name); ?></td>
                    <td><?php echo e(\App\Models\Customer::find($bill->id_customer)->address); ?></td>
                    <td><?php echo e(\App\Models\Customer::find($bill->id_customer)->phone); ?></td>
        			<td><?php echo e(number_format($bill->total_price)); ?></td>
                    <td><?php echo e($bill->payment); ?></td>
                    <td><?php echo e($bill->type_transport); ?></td>
                    <?php if($bill->note == 'đã giao hàng'): ?>
                    	<td><b><?php echo e($bill->note); ?> (Ngày giao: <span style="color:red"><?php echo e($bill->updated_at); ?>)</span></b></td>
                    <?php else: ?>
                    	<td><b><?php echo e($bill->note); ?></b></td>
             		<?php endif; ?>                   
                    <td><?php echo e($bill->created_at); ?></td>
                    <td><a href="<?php echo e(route('order_history_detail', $bill->id)); ?>">Xem chi tiết</a></td>
			    </tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  </tbody>
		</table>
	</div>
	<div class="row">
		<div style="display: flex; justify-content: center;">
		<ul class="pagination pagination-lg">
			
            <li class="page-item"><a class="page-link" href="lich-su-mua-hang?page=1">First</a></li>
            
            <?php if($bills->currentPage() > 1): ?>
                <li class="page-item"><a class="page-link" href="lich-su-mua-hang?page=<?php echo e($bills->currentPage() - 1); ?>">Previous</a></li>
            <?php endif; ?>
                <li class="page-item active"><a class="page-link" href="lich-su-mua-hang?page=<?php echo e($bills->currentPage()); ?>"><?php echo e($bills->currentPage()); ?></a></li>
            <?php if($bills->currentPage() < $bills->lastPage()): ?>
                <li class="page-item"><a class="page-link" href="lich-su-mua-hang?page=<?php echo e($bills->currentPage() + 1); ?>"><?php echo e($bills->currentPage() + 1); ?></a></li>
                <?php if($bills->currentPage() < $bills->lastPage() - 2): ?>
                <li class="page-item"><a class="page-link" href="lich-su-mua-hang?page=<?php echo e($bills->currentPage() + 2); ?>"><?php echo e($bills->currentPage() + 2); ?></a></li>
                <?php endif; ?>
                <?php if($bills->currentPage() < $bills->lastPage() - 3): ?>
                <li class="page-item"><a class="page-link" href="lich-su-mua-hang?page=<?php echo e($bills->currentPage() + 3); ?>"><?php echo e($bills->currentPage() + 3); ?></a></li>
                <?php endif; ?>
            <?php endif; ?>
            
            <?php if($bills->currentPage() < $bills->lastPage()): ?>
                <li class="page-item"><a class="page-link" href="lich-su-mua-hang?page=<?php echo e($bills->currentPage() + 1); ?>">Next</a>
            <?php endif; ?>
            <li class="page-item"><a class="page-link" href="lich-su-mua-hang?page=<?php echo e($bills->lastPage()); ?>">Last</a></li>
		</ul>
	</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/order_history.blade.php ENDPATH**/ ?>