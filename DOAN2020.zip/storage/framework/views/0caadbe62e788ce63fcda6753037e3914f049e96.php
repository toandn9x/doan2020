<!DOCTYPE html>
<html>
<head>
<title>Fast food - Đăng nhập</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<base href="<?php echo e(asset('')); ?>">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="lib/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="lib/css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome icons -->
<link href="lib/css/font-awesome.css" rel="stylesheet" type="text/css" media="all" /> 
<!-- //font-awesome icons -->
<!-- js -->
<script src="lib/js/jquery-1.11.1.min.js"></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
</head>
	
<body>
<!-- login -->
		<div class="w3_login">
			<h3>Đăng nhập & Đăng ký</h3>
			<div class="w3_login_module">
				<div class="module form-module">
				  <div class="toggle"><i class="fa fa-times fa-pencil"></i>
					<div class="tooltip">Click Me</div>
				  </div>
				  <div class="form">
					<h2>Đăng nhập</h2>
					<?php if($errors->any()): ?>
					    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        <div class="alert alert-danger"><?php echo e($error); ?></div>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					<?php if(session('err')): ?>
					    <div class="alert alert-danger">
					        <?php echo e(session('err')); ?>

					    </div>
  					<?php endif; ?>
  					<?php if(session('success')): ?>
					    <div class="alert alert-success">
					        <?php echo e(session('success')); ?>

					    </div>
  					<?php endif; ?>
					<form action="<?php echo e(route('p_login')); ?>" method="post">
						<?php echo csrf_field(); ?>
					  <input type="email" name="email" placeholder="Nhập địa chỉ email" required=" ">
					  <input type="password" name="password" placeholder="Nhập mật khẩu" required=" ">
					  <input type="submit" value="Đăng nhập">
					</form>
				  </div>
				  <div class="form">
					<h2>Đăng ký tài khoản</h2>
					<?php if(session('err2')): ?>
					    <div class="alert alert-danger">
					        <?php echo e(session('err')); ?>

					    </div>
					<?php endif; ?>
					<?php if(session('success')): ?>
					    <div class="alert alert-success">
					        <?php echo e(session('success')); ?>

					    </div>
  					<?php endif; ?>
					<form action="<?php echo e(route('p_register')); ?>" method="post">
						<?php echo csrf_field(); ?>
					  <input type="email" name="email" placeholder="Nhập địa chỉ email" required=" ">
					  <input type="password" name="password" placeholder="Nhập mật khẩu" required=" ">
					  <input type="password" name="repass" placeholder="Nhập lại mật khẩu" required=" ">
					  <input type="text" name="username" placeholder="Nhập tên" required=" ">
					  <input type="submit" value="Đăng ký">
					</form>
				  </div>
				  <div class="cta"><a href="<?php echo e(route('g_reset_pass')); ?>">Quên mật khẩu?</a></div>
				</div>
			</div>
			<script>
				$('.toggle').click(function(){
				  // Switches the Icon
				  $(this).children('i').toggleClass('fa-pencil');
				  // Switches the forms  
				  $('.form').animate({
					height: "toggle",
					'padding-top': 'toggle',
					'padding-bottom': 'toggle',
					opacity: "toggle"
				  }, "slow");
				});
			</script>
		</div>
<!-- //login -->
	</div>
<!-- //banner -->
<!-- newsletter-top-serv-btm -->
	
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/login.blade.php ENDPATH**/ ?>