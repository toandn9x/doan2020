<!-- footer -->
	<div class="footer">
		<div class="container" style="color: #fff">
			<div class="col-md-4">
				<img src="images/<?php echo e($img); ?>">
			</div>
			<div class="col-md-4">
				<h4>FAST FOOD</h4>
				<hr>
				<p>Trụ Sở Chính: <?php echo e($post[1]); ?></p>
				<p>	Hotline: <?php echo e($post[2]); ?> </p>
				<p>	Email: <?php echo e($post[3]); ?></p>
				<p>	Huớng dẫn đặt hàng</p>
				<p>	Chính sách thanh toán</p>
				<p>	Chính sách giao hàng</p>
				<p>	Chính sách đổi trả</p>
			</div>
			<div class="col-md-4">
				<h4>LIKE FACEBOOK</h4>
				<hr>
				<div id="fb-root"></div>
					<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v9.0&appId=228541844339630&autoLogAppEvents=1" nonce="5GQAxjI2"></script>
			
				<div class="fb-page" data-href="https://www.facebook.com/To%C3%A0n-122548605065565" data-tabs="" data-width="" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/To%C3%A0n-122548605065565" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/To%C3%A0n-122548605065565">Toàn</a></blockquote></div>
			</div>
		</div>
		<div class="wthree_footer_copy">
			<p>© 2020 All rights reserved</p>
		</div>
		</div>
	</div>
<!-- //footer --><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/footer.blade.php ENDPATH**/ ?>