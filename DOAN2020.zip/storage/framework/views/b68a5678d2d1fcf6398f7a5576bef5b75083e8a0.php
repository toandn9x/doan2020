
<?php $__env->startSection('title', 'QL Slide'); ?>
<?php $__env->startSection('content_admin'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>QL Slide</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <a href="<?php echo e(route('g_add_slide')); ?>" class="btn btn-info">Thêm</a> | 
                <a href="javascript:void(0)" class="btn btn-danger" style="" id="slide_delete">Xóa</a>
              </div>
              <div class="card-body">
              	<table class="table table-hover">
        				  <thead>
        				    <tr>
                      <th scope="col"></th>
        					    <th scope="col">STT</th>
        					    <th scope="col">Ảnh</th>
        					    <th scope="col">Liên kết</th>
        					    <th scope="col">Trạng thái</th>
        					    <th scope="col">Ngày tạo</th>
                      <th scope="col">Sửa</th>
        				    </tr>
        				  </thead>
        				  <tbody id="slide_table">
        				  	<?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        				        <tr>
                          <th scope="row"><input class="form-check-input" type="checkbox" value="<?php echo e($slide->id); ?>" id="<?php echo e($slide->id); ?>"></th>
        					      	<th scope="row"><?php echo e($key+1); ?></th>
        					      	<td class="example"><img src="images/<?php echo e($slide->image); ?>" width="200px" height="100px" style="cursor: pointer;"></td>
        					      	<td><?php echo e($slide->link); ?></td>
                          <?php if($slide->status == Config::get('constants.STATUS_ACTIVE')): ?>
                          <td>✔ Đang hiển thị</td>
                          <?php else: ?> <td><span style="color:red">✘ Đang ẩn</span></td>
                          <?php endif; ?>
        					      	<td><?php echo e($slide->created_at); ?></td>
                          <td><a href="<?php echo e(route('g_edit_slide', $slide->id)); ?>">Sửa</a></td>
        				    	</tr>
        				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        				  </tbody>
				        </table>
            </div>
				<div class="card-footer">
        	<div class="row">
            <div class="col-md-4" id="count_slide">Show <?php echo e($slides->count()); ?> of <?php echo e($slides->total()); ?> result</div>
            <div class="col-md-8">  	
            	<ul class="pagination float-right">
            		
            		<li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=1">First</a></li>
            		
            		<?php if($slides->currentPage() > 1): ?>
			    	        <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($slides->currentPage() - 1); ?>">Previous</a></li>
			          <?php endif; ?>
			              <li class="page-item active"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($slides->currentPage()); ?>"><?php echo e($slides->currentPage()); ?></a></li>
			          <?php if($slides->currentPage() < $slides->lastPage()): ?>
				            <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($slides->currentPage() + 1); ?>"><?php echo e($slides->currentPage() + 1); ?></a></li>
                    <?php if($slides->currentPage() < $slides->lastPage() - 2): ?>
				            <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($slides->currentPage() + 2); ?>"><?php echo e($slides->currentPage() + 2); ?></a></li>
                    <?php endif; ?>
                    <?php if($slides->currentPage() < $slides->lastPage() - 3): ?>
				            <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($slides->currentPage() + 3); ?>"><?php echo e($slides->currentPage() + 3); ?></a></li>
                    <?php endif; ?>
				        <?php endif; ?>
  							
  							<?php if($slides->currentPage() < $slides->lastPage()): ?>
  								  <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($slides->currentPage() + 1); ?>">Next</a>
  							<?php endif; ?>
			          <li class="page-item"><a class="page-link" href="admin/ql-tai-khoan?page=<?php echo e($slides->lastPage()); ?>">Last</a></li>
			        </ul>
            </div>
      	  </div>
        </div>
              <!-- /.card-body -->
      </div>
            <!-- /.card -->
    </div>
          <!-- /.col -->
  </div>
        <!-- /.row -->
   </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
  function ajaxDeleteSlide(id) {
    //alert(id);
    $.confirm({
      title: 'Xác Nhận!',
      content: 'Bạn có chắc chắn muốn xóa (những) ảnh này ?',
      type: 'red',
      typeAnimated: true,
      buttons: {
          tryAgain: {
              text: 'Ok',
              btnClass: 'btn-red',
              action: function(){
                $.ajax({
                    url : '<?php echo e(route('p_delete_slide')); ?>',
                    type : 'post',
                    data : {
                          'id': id,
                          },
                    success : function (data){
                      console.log(data);
                      if(data == "success") {
                        toastr.success('Xóa slide thành công!');
                        setTimeout(function(){location.reload(); }, 1000);
                      }
                      else {
                        toastr.error('Xóa không thành công, vui lòng chọn một slide!');
                      }
                    }
                });
              }
          },
          close: function () {
          }
      }
    });
  }
</script>
<script>
// xóa hàng loạt
$('#slide_delete').click(function(){
  let listId = '';
  $.each($("input[type=checkbox]:checked"), function(){
    listId += $(this).val() + ',';
  });
  listId = listId.substring(0, listId.length - 1);
  ajaxDeleteSlide(listId);
})
</script>
<script>
  $('.example').mtfpicviewer({
    selector: 'img',
    attrSelector: 'src',
    
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/admin/slide.blade.php ENDPATH**/ ?>