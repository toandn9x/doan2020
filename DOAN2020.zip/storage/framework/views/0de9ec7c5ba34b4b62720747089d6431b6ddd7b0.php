
<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('content'); ?>
<style>
	img {
  display: block !important;
  max-width:320px !important;
  max-height:150px !important;
  width: auto !important;
  height: auto !important;
	}
</style>
    
	<div class="fresh-vegetables" id="hot">
		<h3>Hot Products</h3>
		<div class="container">
			<div class="agile_top_brands_grids">
				<?php $__currentLoopData = $products_hot->skip(0)->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-3 top_brand_left">
					<div class="hover14 column">
						<div class="agile_top_brand_left_grid">
							<div class="tag"><img src="lib/images/hot.png" alt=" " class="img-responsive" style="margin: -5px"></div>
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block">
										<div class="snipcart-thumb">
											<a href="<?php echo e(route('product_detail', $hot->id)); ?>"><img title=" " alt=" " src="images/<?php echo e($hot->image); ?>" width="320px" height="150px"></a>		
											<p><?php echo e($hot->name); ?></p>
											<?php if(isset($hot->promotional_price) && $hot->promotional_price != 0): ?>
											<h4><?php echo e(number_format($hot->promotional_price)); ?> đ<span><?php echo e(number_format($hot->unit_price)); ?> đ</span></h4>
											<?php else: ?>
											<h4 style="text-align: center;"><?php echo e(number_format($hot->unit_price)); ?> đ</h4>
											<?php endif; ?>
										</div>
										<div class="snipcart-details top_brand_home_details">
											<fieldset>
												<input type="button" value="Add to cart" class="button" id="add_product2" onclick="addCart(<?php echo e($hot->id); ?>, '<?php echo e($hot->image); ?>', '<?php echo e($hot->unit_price); ?>', '<?php echo e($hot->promotional_price ? $hot->promotional_price : 0); ?>', 1)">
											</fieldset>
										</div>
									</div>
								</figure>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			</div>
		</div>
		<div class="container">
			<div class="agile_top_brands_grids">
				<?php $__currentLoopData = $products_hot->skip(4)->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-3 top_brand_left">
					<div class="hover14 column">
						<div class="agile_top_brand_left_grid">
							<div class="tag"><img src="lib/images/hot.png" alt=" " class="img-responsive" style="margin: -5px"></div>
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block">
										<div class="snipcart-thumb">
											<a href="<?php echo e(route('product_detail', $hot->id)); ?>"><img title=" " alt=" " src="images/<?php echo e($hot->image); ?>" width="320px" height="150px"></a>		
											<p><?php echo e($hot->name); ?></p>
											<?php if(isset($hot->promotional_price) && $hot->promotional_price != 0): ?>
											<h4><?php echo e(number_format($hot->promotional_price)); ?> đ<span><?php echo e(number_format($hot->unit_price)); ?> đ</span></h4>
											<?php else: ?>
											<h4 style="text-align: center;"><?php echo e(number_format($hot->unit_price)); ?> đ</h4>
											<?php endif; ?>
										</div>
										<div class="snipcart-details top_brand_home_details">
											<fieldset>
												<input type="button" value="Add to cart" class="button" id="add_product1" onclick="addCart(<?php echo e($hot->id); ?>, '<?php echo e($hot->image); ?>', '<?php echo e($hot->unit_price); ?>', '<?php echo e($hot->promotional_price ? $hot->promotional_price : 0); ?>', 1)">
											</fieldset>
										</div>
									</div>
								</figure>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
	
	<hr>
	<h3 style="text-align: center; font-size: 40px">MENU</h3>
	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
	<?php
	// select * from product where id = ? AND (STATUS = ACTIVE OR STATUS = SELL_OUT) order by (id,desc) limit 4
	$products = \App\Models\Product::where(['id_category' => $category->id])
		->where(function ($query) {
			$query->where('status', Config::get('constants.STATUS_ACTIVE'))
				  ->orWhere('status', Config::get('constants.STATUS_SELL_OUT'));
		})
		->orderBy('id', 'desc')
		->limit(4)
		->get();
	?>
	
	<div class="container" id = "<?php echo e($category->id); ?>">
		<br>
		<hr>
		<h3 style="padding-left: 20px"><span style="color:red">✔</span><a href="san-pham/<?php echo e($category->id); ?>"> <?php echo e($category->name); ?></a></h3>
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="agile_top_brands_grids">
				<div class="col-md-3 top_brand_left">
					<div class="hover14 column">
						<div class="agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block" >
										<div class="snipcart-thumb">
											<a href="<?php echo e(route('product_detail', $product->id)); ?>"><img title=" " alt=" " src="images/<?php echo e($product->image); ?>" width="320px" height="150px"></a>		
											<p><?php echo e($product->name); ?></p>
											<?php if(isset($product->promotional_price) && $product->promotional_price != 0): ?>
											<h4><?php echo e(number_format($product->promotional_price)); ?> đ <span><?php echo e(number_format($product->unit_price)); ?> đ</span></h4>
											<?php else: ?>
											<h4 style="text-align: center;"><?php echo e(number_format($product->unit_price)); ?> đ</h4>
											<?php endif; ?>
										</div>
										<div class="snipcart-details top_brand_home_details">
											<fieldset>
												<?php if($product->status == Config::get('constants.STATUS_ACTIVE')): ?>
												<input type="button" value="Add to cart" class="button" id="add_product" onclick="addCart(<?php echo e($product->id); ?>, '<?php echo e($product->image); ?>', '<?php echo e($product->unit_price); ?>', '<?php echo e($product->promotional_price ? $product->promotional_price : 0); ?>', 1)">
												<?php else: ?>
												<input type="button" value="Hết Hàng" class="button" id="" style="background: #ccc">
												<?php endif; ?>
											</fieldset>
										</div>
									</div>
								</figure>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<hr>
	<div class="newsletter">
		<div class="container">
			<div class="w3agile_newsletter_left">
				<h3>Nhận thông tin khuyến mãi: </h3>
			</div>
			<div class="w3agile_newsletter_right">
				<input type="email" id="email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}" required="" placeholder="Nhập email...">
				<input type="submit" value="Gửi" id="send_info">
				
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //top-brands -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
	function addCart(product_id, product_img, product_price, product_promotion_price, qty) {
		let price = '';
		if(product_promotion_price == 'undefined' || product_promotion_price == '' || product_promotion_price == 0) {
			price = product_price;
		}
		else {
			price = product_promotion_price;
		}
		$.ajax({
	        url : '<?php echo e(route('add_cart')); ?>',
	        type : 'post',
	        data : {
	              'id'		: product_id,
	              'img' 	: product_img,
	              'price' 	: price,
	              'qty' 	: qty
	              },
	        success : function (data){
	        	let obj = JSON.parse(data);
	        	//console.log(obj);
		        if(obj.status == 1) {
		          	swal("Thêm thành công!", "Sản phẩm được thêm vào giỏ hàng", "success")
		          	.then((value) => {
					  $('#cart').val(obj.qty + ' Sản phẩm 　');
					});
		        }
	          	else swal("Lỗi!", "Có lỗi, vui lòng thử lại", "error");
	        }
	    });

	}
</script>
<!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>
window.fbAsyncInit = function() {
  FB.init({
    xfbml            : true,
    version          : 'v9.0'
  });
};

(function(d, s, id) {
var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = 'https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js';
fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your Chat Plugin code -->
<div class="fb-customerchat"
attribution=setup_tool
page_id="122548605065565"
theme_color="#fa3c4c"
logged_in_greeting="Fast Food xin chào bạn. Tôi có thể giúp gì cho bạn ?"
logged_out_greeting="Fast Food xin chào bạn. Tôi có thể giúp gì cho bạn ?">
</div>
<script>
	// chức năng đăng ký nhận tin khuyến mãi !
	function isEmail(email) {
	  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	  return regex.test(email);
	}
	$('#send_info').click(function() {
		if($('#email').val() == '') {
			swal("error!", "Vui lòng nhập email", "error");
			return;
		}
		if(isEmail($('#email').val()) == false) {
			swal("error!", "Email không đúng định dạng", "error");
			return;
		}
		$.ajax({
	        url : '<?php echo e(route('get_discount')); ?>',
	        type : 'post',
	        data : {
	              'email' : $('#email').val(),
	              },
	        success : function (data){
	        	console.log(data);
	        	if(data == 'success') {
	        		swal("Success!", "Chúng tôi sẽ gửi thông tin các chương trình khuyến mãi vào email bạn đã đăng ký. Xin cảm ơn!", "success");
	        	}
	        	else {
	        		swal("error!", "Email đã được đăng ký!", "error");
	        	}
	        }
	    });
	})
</script>
<script>
	// keep position when reload page
    $(window).scroll(function () {
        sessionStorage.scrollTop = $(this).scrollTop();
    });
    $(document).ready(function () {
        if (sessionStorage.scrollTop != "undefined") {
            $(window).scrollTop(sessionStorage.scrollTop);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DOAN2020\resources\views/index.blade.php ENDPATH**/ ?>